###################################################################################################################
###################################################################################################################
################################      -- MAYEL MALEBE TD1 - TP B --    ############################################
########################## -- DEVELOPPEMENT D'APPLICATION AVEC INTERFACE HOMME MACHINE -- #########################
################################ -- INITIATION MVC - INETERFACE ANNUAIRE / PERSONNES -- ###########################
############################## -- CLASSE : VUE_ANNUAIRE ===> rendu le 01/05/2022 -- ###############################
###################################################################################################################
###################################################################################################################

# --- import
import sys
from tkinter import Button
from PyQt6.QtWidgets import QApplication, QWidget, QSlider, QLineEdit, QTextEdit, QCalendarWidget, QPushButton, QHBoxLayout,QVBoxLayout, QLabel, QComboBox, QDateEdit, QBoxLayout
from PyQt6.QtGui import QScreen
from PyQt6.QtCore import Qt, QDate, pyqtSignal
import datetime, genre as g
import vuePersonne

# -------------------------------------------------

class vueAnnuaire(QWidget):
    # signal
    nextClicked = pyqtSignal()
    previousClicked = pyqtSignal()
    openFileClicked = pyqtSignal(str)
    newClicked = pyqtSignal()
    personneChanged = pyqtSignal(dict)
    saveAsClicked =pyqtSignal(str)
    
# -------------------------------------------------

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Annuaire")

# -------------------------------------------------

        self.bvLayout = QVBoxLayout()
        self.setLayout(self.bvLayout)
        self.personne = vuePersonne.vuePersonne()
        self.bvLayout.addWidget(self.personne)
        # ---- Ajout des boutons du bas ---- #
        self.tbete = QWidget()
        self.innerlayout = QHBoxLayout()
        self.tbete.setLayout(self.innerlayout)
        
        self.previous : QPushButton = QPushButton(" << Previous")
        self.load : QPushButton = QPushButton("Load") 
        self.new : QPushButton = QPushButton("New")
        self.saveas : QPushButton = QPushButton("Save as")
        self.next : QPushButton = QPushButton("Next >> ")

        self.innerlayout.addWidget(self.previous,1)
        self.innerlayout.addWidget(self.load,1)
        self.innerlayout.addWidget(self.new,1)
        self.innerlayout.addWidget(self.saveas,1)    
        self.innerlayout.addWidget(self.next,1) 
        
        self.bvLayout.addWidget(self.tbete)
        self.previous.clicked.connect(self.precedent)
        self.load.clicked.connect(self.charger)
        self.new.clicked.connect(self.nouveau)
        self.saveas.clicked.connect(self.sauvegarder)
        self.next.clicked.connect(self.suivant)
        
        # lets show 
        self.show()
        
# -------------------------------------------------
    
    def updatePersonne(self, prenom,nom, genre, nee, mort, bio):
        self.personne.updatePersonne(prenom, nom, genre, nee, mort, bio)

# -------------------------------------------------

    def precedent(self):
        self.previousClicked.emit()
        
# -------------------------------------------------
    
    def nouveau(self):
        self.newClicked.emit()   
        
# -------------------------------------------------
        
    def suivant(self):
        self.nextClicked.emit()  
        
# -------------------------------------------------
        
    def charger(self):
        self.openFileClicked.emit("json.file")

# -------------------------------------------------
        
    def sauvegarder(self):
        self.saveAsClicked.emit("json.file") 
        
# -------------------------------------------------
        
        
# -- main kind of unit test --
if __name__ == "__main__":    
    app = QApplication(sys.argv)
    f = vueAnnuaire()
    sys.exit(app.exec())


#####################################################################################################
#####################################  -- FIN DU PROGRAMME --  ######################################
#####################################################################################################
    
    
    
    
    