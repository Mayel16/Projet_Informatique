<template>
  <div class="list">
  
    <article v-for="pokemon in pokemonsFiltered" :key="pokemon.name" v-on:click="showpokemon(pokemon.url)">
      <img :src = " 'https://img.pokemondb.net/sprites/bank/normal/' + pokemon.name + '.png'"/>
        <h3>{{ pokemon.name }}</h3>
    </article>
  </div>


</template>

<script>
import _ from "lodash";
import axios from 'axios';
export default {
  props: ['pokemon_recherche'],
  name: 'PokemonList',
  data() {
    return {
      pokemonlist:[],
    };
  }, 

  computed: {
  pokemonsFiltered() {
    return _.filter(this.pokemonlist, (pokemon) => {
      return pokemon.name.toLowerCase().startsWith(this.pokemon_recherche.toLowerCase());
    });
  }
},
  mounted () {
    axios
      // avec => =0&limit=-1 j'affiche tout les pokemons
      .get("https://pokeapi.co/api/v2/pokemon?ofset=0&limit=-1")
      .then(response => { this.pokemonlist = response.data.results });
    },
  methods: {
    showpokemon(pokemon) {
      this.$emit('showpokemon', pokemon);
    }},

}
</script>





<style lang="scss" scoped>
.list {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  grid-gap: 10px;
  width: 100%;
  max-width: 510px;
}
article {
  height: 150px;
  background-color: #efefef;
  text-align: center;
  text-transform: capitalize;
  border-radius: 5px;
  cursor: pointer;
  box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2), 0 10px 10px rgba(0, 0, 0, 0.2);
}
h3 {
  margin: 0;
}
#scroll-trigger {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 150px;
  font-size: 2rem;
  color: #efefef;
}

img {
  width: 96px;
  height: 96px;
}
</style>

