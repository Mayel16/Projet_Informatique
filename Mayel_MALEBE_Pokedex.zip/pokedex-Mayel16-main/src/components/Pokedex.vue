<template>
  <div class="container">
    <PokemonSearch PokemonSearch v-on:Search=" recherche" @showpokemon ="showpoke"/>
    <PokemonDetail :pokemon_URL = "envoi" :pokemonUrl = "url" v-if= "verif"  v-on:closePokemon="verif=false"/>
    <PokemonList v-on:showpokemon = "update" :pokemon_recherche = "recherche" />
  </div>
</template>

<script>
import PokemonDetail from "../components/PokemonDetail.vue";
import PokemonList from "../components/PokemonList.vue";
import PokemonSearch from "../components/PokemonSearch.vue";

export default {
  components: {
    PokemonDetail,
    PokemonList,
    PokemonSearch,
  },
  data : function() {
    return {
      verif : false,
      envoi: null,
      listPokemon : [],
      url : "https://pokeapi.co/api/v2/pokemon/",
      recherche : "",
    };
  },
  methods: {
    update : function(pok){
      this.verif=true;
      this.envoi=pok;
    },
    showpoke(pokemon){
      console.log(pokemon);
      this.recherche = pokemon;
    }
  },
};
</script>





<style lang="scss" scoped>
.container {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  padding: 10px;
  width: calc(100% - 20px);
  min-height: calc(100vh - 20px);
  //background: radial-gradient(#ffbf0b, #e20000);
  
  font-family: "Acme", arial;
  font-size: 1rem;
  font-weight: normal;
}

h1 {
  color: #efefef;
}
</style>