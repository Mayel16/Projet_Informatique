#pragma once

#ifndef __RANDOM_H__
#define __RANDOM_H__

class Random
{

private:

	Random() = default;

	float nb_genere(const float minimum, const float maximum) const;

public:

	Random(const Random&) = delete;

	Random(Random&&) = delete;

	~Random() = default;

	static const Random& get();

	static float rand(const float minimum = 0.0f, const float maximum = 10.0f);
};

#endif 