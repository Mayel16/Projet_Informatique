#pragma once

#ifndef __GRID_H__
#define __GRID_H__

#include <vector>
#include <include/Position.hpp>

class Plateau
{
public:

	Plateau(const size_t& plateau_lignes, const size_t& plateau_colonnes, bool remplir = true, bool tore2 = false);

	Plateau(const Plateau&) = delete;

	Plateau(Plateau&&) = delete;

	~Plateau();

	void ajout_cellule(const int x, const int y);

	void ajout_cellule(const std::vector<Position>& cells);

	void detruit_la_cellule(const int x, const int y);

	int voisins(const int x, const int y) const;

	const size_t& plateau_lignes() const;

	const size_t& plateau_colonnes() const;

	int nb_vie() const;

	int nb_mort() const;

	float pourcentage_vie() const;

	float pourcentage_mort() const;
	
	bool empty() const;

	void generation(const int gen = 1);

	void affiche_plateau() const;

	void efface();
	inline int modulo(int a, int b) const;

	uint8_t* operator[](const size_t& index);

	Plateau& operator=(const Plateau&) = default;


private:

	bool tore;

	uint8_t** tableau;

	size_t lines; 

	size_t col;

	size_t taille = 0;

	std::vector<std::pair<bool, Position>> position_cellules;
};

#endif 
