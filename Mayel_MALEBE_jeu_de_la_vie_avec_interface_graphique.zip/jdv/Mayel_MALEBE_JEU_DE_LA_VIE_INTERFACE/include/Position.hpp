#pragma once

#ifndef __POSITION_H__
#define __POSITION_H__

#include <ostream>

class Position
{
public:
	
	/**
	* @brief
	*/
	Position(const int x, const int y);
	/**
	* @brief
	*/
	Position(const Position&) = delete;
	/**
	* @brief
	*/
	Position(Position&&) = default;
	/**
	* @brief
	*/
	~Position();
	/**
	* @brief
	*/
    int x() const;
	/**
	* @brief
	*/
    int y() const;
	/**
	* @brief
	*/
	Position& operator=(Position&&) = default;
	/**
	* @brief
	*/
	bool operator==(const Position& other) const;
	/**
	* @brief
	*/
	bool operator!=(const Position& other) const;
	/**
	* @brief
	*/
	friend std::ostream& operator<<(std::ostream& ostream, const Position& _this);

private:

	int _x, _y;
};

#endif // !__POSITION_H__