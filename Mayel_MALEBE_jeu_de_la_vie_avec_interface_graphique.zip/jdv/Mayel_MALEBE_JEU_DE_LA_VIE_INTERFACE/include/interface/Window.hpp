#ifndef __WINDOW_H__
#define __WINDOW_H__

#include <QWidget>

class GridWidget;
class QPushButton;

class Window : public QWidget
{
    Q_OBJECT

public:

    explicit Window(QWidget* parent = nullptr);

private slots:

    void buttonPressed();

private:

    GridWidget* m_grid_widget;
    QPushButton* m_start_button;
    QPushButton* m_stop_button;
};

#endif // !__WINDOW_H__
