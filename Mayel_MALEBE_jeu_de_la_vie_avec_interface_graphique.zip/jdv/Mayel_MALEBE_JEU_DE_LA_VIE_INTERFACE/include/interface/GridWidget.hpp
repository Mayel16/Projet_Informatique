#ifndef __GRID_WIDGET_H__
#define __GRID_WIDGET_H__

#include <QWidget>

class Plateau;
class QGridLayout;
class QPushButton;

class GridWidget : public QWidget
{
    Q_OBJECT

public:

    explicit GridWidget(Plateau& grid, QWidget* parent = nullptr);

    void draw();

signals:


private:

    Plateau& tableau;
    int m_rows;
    int m_columns;
    QGridLayout* m_layout;
    QPushButton** m_buttons;
};

#endif // !__GRID_WIDGET_H__
