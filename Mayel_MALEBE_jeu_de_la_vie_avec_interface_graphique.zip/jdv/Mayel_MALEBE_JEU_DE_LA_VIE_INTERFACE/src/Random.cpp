#include <include/Random.hpp>
#include <random>

const Random& Random::get()
{
	static Random m_random;
	
	return m_random;
}

float Random::rand(const float min, const float max)
{
	return get().nb_genere(min, max);
}

float Random::nb_genere(const float min, const float max) const
{
	std::random_device random_device;
    std::minstd_rand mt(random_device());
    std::uniform_real_distribution<float> distribution(min, max);

    return distribution(mt);
};
