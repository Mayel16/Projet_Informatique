#include<include/Plateau.hpp>
#include <include/interface/GridWidget.hpp>
#include <include/interface/Window.hpp>
#include<iostream>
#include <QApplication>

int main(int argc, char* argv[])
{
    /* Plateau avec une dimension par défaut */
    Plateau p1(50, 50);
    size_t lignes = 0, colonnes = 0;
    /* Je demande à l'user de saisir les dimensions du tableau*/
    std::cout<<"\nSaisissez le nombre de lignes : ";
    std::cin >> lignes;
    std::cout<<"\nSaisissez le nombre de colonnes : ";
    std::cin>> colonnes;
    // Affichage
    //Plateau p3(lignes, colonnes);
    printf("\n----- Voici votre plateau -----\n");
    // p1.affiche_plateau();
    printf("\n|-------------- X --------------|\n");
    p1.affiche_plateau();
    printf("\n|-------------- X --------------|\n");
    //p1.generation(2);
    std::cout << p1.nb_vie() << std::endl;
    std::cout << p1.nb_mort() << std::endl;
    std::cout << p1.pourcentage_mort() << '%' << std::endl;

    //////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////// Partie graphique ///////////////////////////////////

    QApplication app(argc, argv);
    Window* fenetre = new Window();
    GridWidget p(p1);
    fenetre->setLayout(p.layout());
    fenetre->show();
    while (true){
        p1.generation();
        p.draw();
        app.processEvents();
    }
    return app.exec();
}
