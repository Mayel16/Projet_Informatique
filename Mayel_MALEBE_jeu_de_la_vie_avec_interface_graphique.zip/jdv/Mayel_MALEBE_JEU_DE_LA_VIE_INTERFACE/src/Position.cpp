#include <include/Position.hpp>

Position::Position(const int x, const int y) : _x(x), _y(y) {}

Position::~Position() {}

int Position::x() const
{
	return _x;
}

int Position::y() const
{
	return _y;
}

bool Position::operator==(const Position& other) const
{
	return (other._x == _x && other._y == _y);
}

bool Position::operator!=(const Position& other) const
{
	return !(*this == other);
}

std::ostream& operator<<(std::ostream& ostream, const Position& _this)
{
	ostream << '[' << _this._x << ',' << _this._y << ']';
	return ostream;
}
