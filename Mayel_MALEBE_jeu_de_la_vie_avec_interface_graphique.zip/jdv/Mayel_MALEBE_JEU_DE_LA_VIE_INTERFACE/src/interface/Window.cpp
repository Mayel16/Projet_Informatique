#include <include/interface/Window.hpp>
#include <include/interface/GridWidget.hpp>
#include <QGridLayout>
#include <QPushButton>

Window::Window(QWidget* parent)
    : QWidget{parent}, m_grid_widget(nullptr)
{
    setFixedSize(1080, 720);
    //m_grid_widget->move(0,0);
}

void Window::buttonPressed()
{

}
