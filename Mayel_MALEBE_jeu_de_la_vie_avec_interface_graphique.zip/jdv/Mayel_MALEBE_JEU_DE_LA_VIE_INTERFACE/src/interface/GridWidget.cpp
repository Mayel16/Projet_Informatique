#include <include/interface//GridWidget.hpp>
#include <include/Plateau.hpp>
#include <QGridLayout>
#include <QPushButton>

GridWidget::GridWidget(Plateau& grid, QWidget* parent)
    : QWidget{parent}, tableau(grid), m_rows(tableau.plateau_lignes()), m_columns(tableau.plateau_colonnes()), m_layout(new QGridLayout()), m_buttons(new QPushButton* [m_rows])
{
    for (int i = 0; i < m_rows; i++)
    {
        m_buttons[i] = new QPushButton[m_columns];

        for (int j = 0; j < m_columns; j++)
        {
            m_buttons[i][j].setCheckable(true);
            m_layout->addWidget(&m_buttons[i][j], i, j);

            if (tableau[i][j] == '1')
            {
                m_buttons[i][j].setCheckable(false);
                m_buttons[i][j].setStyleSheet("background-color: black;");
            }
        }
    }

    //setFixedSize(700,500);
    setLayout(m_layout);
}

void GridWidget::draw()
{
    for (int i = 0; i < m_rows; i++)
    {
        for (int j = 0; j < m_columns; j++)
        {
            if (tableau[i][j] =='1')
            {
                m_buttons[i][j].setCheckable(false);
                m_buttons[i][j].setStyleSheet("background-color: black;");
            }
            else
            {
                m_buttons[i][j].setCheckable(true);
                m_buttons[i][j].setStyleSheet("background-color: white;");
            }
        }
    }
}
