#include <include/Plateau.hpp>
#include <include/Random.hpp>
#include <iostream> 

Plateau::Plateau(const size_t& plateau_lignes, const size_t& plateau_colonnes, bool remplir, bool tore2) : lines(plateau_lignes), col(plateau_colonnes)
{
	tore = tore2;  
	tableau = new uint8_t * [lines];
	for (size_t i = 0; i < lines; i++)
	{
		tableau[i] = new uint8_t[col];
	}

	if (remplir)
	{
		for (size_t i = 0; i < lines; i++)
		{
			for (size_t j = 0; j < col; j++)
			{
				if (Random::rand() <= 1.0f)
				{
					tableau[i][j] = '1';
					position_cellules.emplace_back(std::make_pair(true, Position(i, j)));
				}
				else
				{
					tableau[i][j] = ' ';
				}
			}
		}
	}
	else
	{
		for (size_t i = 0; i < lines; i++)
		{
			for (size_t j = 0; j < col; j++)
			{
				tableau[i][j] = ' ';
			}
		}
	}
}

Plateau::~Plateau()
{
	for (size_t i = 0; i < lines; i++)
	{
		delete[] tableau[i];
	}

	delete[] tableau;
}

void Plateau::ajout_cellule(int x, int y)
{
	if (tableau[x][y] != '1')
	{
		tableau[x][y] = '1';
		position_cellules.emplace_back(std::make_pair(true, Position(x, y)));
	}
}

void Plateau::ajout_cellule(const std::vector<Position>& cells)
{
	for (const Position& cell : cells)
	{
		ajout_cellule(cell.x(), cell.y());
	}
}

void Plateau::detruit_la_cellule(int x, int y)
{
	if (tableau[x][y] == '1')
	{
		for (auto& cell : position_cellules)
		{
			if (cell.first && cell.second == Position(x, y))
			{
				cell.first = false;
				break;
			}
		}

		tableau[x][y] = '0';
	}
}

int Plateau::voisins(const int x, const int y) const
{
	int voisins = 0;
	
	if (tore){
		for (int i = -1; i < 2; i++)
		{
			for (int j = -1; j < 2; j++)
			{
				if (x + i >= 0 && y + j >= 0)
				{
					if (x + i < lines && y + j < col)
					{
						if (x + i != x || y + j != y)
						{
							if (tableau[modulo(x+i,lines)][modulo(x+j,col)] == '1')
							{
								voisins += 1;
							}
						}
					}
				}
			}
		}

	}
	else {
		for (int i = -1; i < 2; i++)
		{
			for (int j = -1; j < 2; j++)
			{
				if (x + i >= 0 && y + j >= 0)
				{
					if (x + i < lines && y + j < col)
					{
						if (x + i != x || y + j != y)
						{
							if (tableau[x + i][y + j] == '1')
							{
								voisins += 1;
							}
						}
					}
				}
			}
		}
	}

	return voisins;
}

const size_t& Plateau::plateau_lignes() const
{
	return lines;
}

const size_t& Plateau::plateau_colonnes() const
{
	return col;
}

int Plateau::nb_vie() const
{
	int alive_count = 0;

	for (const auto& cell : position_cellules)
	{
		if (cell.first)
		{
			alive_count += 1;
		}
	}

	return alive_count;
}

int Plateau::nb_mort() const
{
	return position_cellules.size() - nb_vie();
}

float Plateau::pourcentage_vie() const
{
	if (position_cellules.empty())
	{
		return 0.0f;
	}
	else
	{
		const size_t& count_alive = nb_vie();
		float percentage = static_cast<float>(count_alive) / position_cellules.size() * 100;

		return percentage;
	}
}

float Plateau::pourcentage_mort() const
{
	if (position_cellules.empty())
	{
		return 0.0f;
	}
	else
	{
		return 100.0f - pourcentage_vie();
	}
}

bool Plateau::empty() const
{
	if (position_cellules.empty())
	{
		return true;
	}

	return false;
}

void Plateau::generation(const int gen)
{
	int tour = 0;

	while (tour != gen)
	{
		uint8_t** copy = new uint8_t * [lines];
		for (size_t i = 0; i < lines; i++)
		{
			copy[i] = new uint8_t[col];
		}

		for (size_t i = 0; i < lines; i++)
		{
			for (size_t j = 0; j < col; j++)
			{
				copy[i][j] = tableau[i][j];
			}
		}

		for (size_t i = 0; i < lines; i++)
		{
			for (size_t j = 0; j < col; j++)
			{
				if (tableau[i][j] == '1')
				{
					if (voisins(i, j) != 2 && voisins(i, j) != 3)
					{
						copy[i][j] = ' ';
						for (auto& cell : position_cellules)
						{
							if (cell.first && cell.second == Position(i, j))
							{
								cell.first = false;
								break;
							}
						}
					}
				}
				else
				{
					if (voisins(i, j) == 3)
					{
						copy[i][j] = '1';
						position_cellules.emplace_back(std::make_pair(true, Position(i, j)));
					}
				}
			}
		}

		for (size_t i = 0; i < lines; i++)
		{
			for (size_t j = 0; j < col; j++)
			{
				tableau[i][j] = copy[i][j];
			}
		}

		for (size_t i = 0; i < lines; i++)
		{
			delete[] copy[i];
		}

		delete[] copy;

		tour += 1;
		affiche_plateau();
	}
}

void Plateau::affiche_plateau() const
{
	for (size_t i = 0; i < lines; i++)
	{
		std::cout << "    " + std::string(-1 + (col * 4), '-') << std::endl;

		if (i < 10)
		{
			std::cout << ' ' << i << " |";
		}
		else
		{
			std::cout << i << " |";
		}

		for (size_t j = 0; j < col; j++)
		{
			std::cout << ' ' << tableau[i][j] << " |";
		}

		std::cout << std::endl;
	}

	std::cout << "    " + std::string(-1 + (col * 4), '-') << std::endl;
}

void Plateau::efface()
{
	for (const auto& cell : position_cellules)
	{
		tableau[cell.second.x()][cell.second.y()] = ' ';
	}

	position_cellules.clear();
}

inline int Plateau::modulo(int a, int b) const {
  const int result = a % b;
  return result >= 0 ? result : result + b;
}

uint8_t* Plateau::operator[](const size_t& index)
{
	if (index >= lines)
	{
		throw std::out_of_range("Index out of range !");
	}

	return tableau[index];
}
